#import <objc/runtime.h>
#import "allincludes.h"
#import "ClassExtension.h"
#import "PointerSupport.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation CAEmitterBehavior (Exports)
-(id) jsinitWithType: (NSString *) type 
{
	id resultVal__;
	resultVal__ = [[self initWithType: type ] autorelease];
	return resultVal__;
}
-(id) jsinitWithCoder: (NSCoder *) aDecoder 
{
	id resultVal__;
	resultVal__ = [[self initWithCoder: aDecoder ] autorelease];
	return resultVal__;
}
@end
static void addProtocols()
{
	class_addProtocol([CAEmitterBehavior class], @protocol(CAEmitterBehaviorInstanceExports));
	class_addProtocol([CAEmitterBehavior class], @protocol(CAEmitterBehaviorClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &kCAEmitterBehaviorColorOverLife;
	if (p != NULL) context[@"kCAEmitterBehaviorColorOverLife"] = kCAEmitterBehaviorColorOverLife;
	p = (void*) &kCAEmitterBehaviorSimpleAttractor;
	if (p != NULL) context[@"kCAEmitterBehaviorSimpleAttractor"] = kCAEmitterBehaviorSimpleAttractor;
	p = (void*) &kCAEmitterBehaviorWave;
	if (p != NULL) context[@"kCAEmitterBehaviorWave"] = kCAEmitterBehaviorWave;
	p = (void*) &kCAEmitterBehaviorValueOverLife;
	if (p != NULL) context[@"kCAEmitterBehaviorValueOverLife"] = kCAEmitterBehaviorValueOverLife;
	p = (void*) &kCAEmitterBehaviorAlignToMotion;
	if (p != NULL) context[@"kCAEmitterBehaviorAlignToMotion"] = kCAEmitterBehaviorAlignToMotion;
	p = (void*) &kCAEmitterBehaviorDrag;
	if (p != NULL) context[@"kCAEmitterBehaviorDrag"] = kCAEmitterBehaviorDrag;
	p = (void*) &kCAEmitterBehaviorAttractor;
	if (p != NULL) context[@"kCAEmitterBehaviorAttractor"] = kCAEmitterBehaviorAttractor;
	p = (void*) &kCAEmitterBehaviorLight;
	if (p != NULL) context[@"kCAEmitterBehaviorLight"] = kCAEmitterBehaviorLight;
}
void load_QuartzCore_CAEmitterBehavior_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop

RENAME TABLE `event_login` TO `users`;

ALTER TABLE `presenter`
	ADD CONSTRAINT `24f7456677e45be1bf806f755ce2bb` FOREIGN KEY(`session_id`) REFERENCES `event_sessions`(`event_session_id`) ON DELETE CASCADE;

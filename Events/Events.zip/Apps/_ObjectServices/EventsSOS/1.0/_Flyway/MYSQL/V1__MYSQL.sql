CREATE TABLE `users`(
	`addressline1` VARCHAR(256),
	`addressline2` VARCHAR(256),
	`city` VARCHAR(128),
	`country` VARCHAR(128),
	`CreatedBy` VARCHAR(32),
	`CreatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`DOB` DATETIME(3),
	`first_name` VARCHAR(256),
	`last_name` VARCHAR(256),
	`LastUpdatedBy` VARCHAR(32),
	`LastUpdatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`login_mode` BIGINT NOT NULL,
	`mail` VARCHAR(256) NOT NULL,
	`mobile` VARCHAR(256),
	`password` VARCHAR(256),
	`profile` VARCHAR(256),
	`SoftDeleteFlag` BOOLEAN,
	`state` VARCHAR(128),
	`user_id` BIGINT NOT NULL AUTO_INCREMENT,
	PRIMARY KEY(`user_id`)
);
CREATE TABLE `presenter`(
	`CreatedBy` VARCHAR(32),
	`CreatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`designation` VARCHAR(256),
	`event_id` BIGINT,
	`LastUpdatedBy` VARCHAR(32),
	`LastUpdatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`linkedin_link` VARCHAR(256),
	`name` VARCHAR(256),
	`presenter_id` BIGINT NOT NULL AUTO_INCREMENT,
	`profile_url` VARCHAR(256),
	`session_id` BIGINT,
	`SoftDeleteFlag` BOOLEAN,
	PRIMARY KEY(`presenter_id`)
);
CREATE TABLE `event_type`(
	`CreatedBy` VARCHAR(32),
	`CreatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`event_type` VARCHAR(128),
	`evet_type_id` BIGINT NOT NULL AUTO_INCREMENT,
	`LastUpdatedBy` VARCHAR(32),
	`LastUpdatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`SoftDeleteFlag` BOOLEAN,
	PRIMARY KEY(`evet_type_id`)
);
CREATE TABLE `event_sessions`(
	`CreatedBy` VARCHAR(32),
	`CreatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`event_id` BIGINT NOT NULL,
	`event_session_id` BIGINT NOT NULL AUTO_INCREMENT,
	`LastUpdatedBy` VARCHAR(32),
	`LastUpdatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`session_desc` VARCHAR(256),
	`session_end_date` DATETIME(3),
	`session_name` VARCHAR(256),
	`session_start_date` DATETIME(3),
	`SoftDeleteFlag` BOOLEAN,
	PRIMARY KEY(`event_session_id`)
);
CREATE TABLE `event`(
	`CreatedBy` VARCHAR(32),
	`CreatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`end_date` DATETIME(3),
	`event_category` BIGINT NOT NULL,
	`event_id` BIGINT NOT NULL AUTO_INCREMENT,
	`event_type` BIGINT NOT NULL,
	`isdisabled` BIGINT,
	`LastUpdatedBy` VARCHAR(32),
	`LastUpdatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`long_desc` VARCHAR(2000),
	`name` VARCHAR(256),
	`short_desc` VARCHAR(256),
	`SoftDeleteFlag` BOOLEAN,
	`start_date` DATETIME(3),
	PRIMARY KEY(`event_id`)
);
CREATE TABLE `event_registration`(
	`CreatedBy` VARCHAR(32),
	`CreatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`event_id` BIGINT NOT NULL,
	`LastUpdatedBy` VARCHAR(32),
	`LastUpdatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`registration_id` BIGINT NOT NULL AUTO_INCREMENT,
	`SoftDeleteFlag` BOOLEAN,
	`user_id` BIGINT NOT NULL,
	PRIMARY KEY(`registration_id`)
);
CREATE TABLE `location`(
	`addressLine1` VARCHAR(200),
	`cityname` VARCHAR(200),
	`CreatedBy` VARCHAR(32),
	`CreatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`event_id` BIGINT NOT NULL,
	`LastUpdatedBy` VARCHAR(32),
	`LastUpdatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`latitude` VARCHAR(45),
	`location` VARCHAR(2000),
	`location_id` BIGINT NOT NULL AUTO_INCREMENT,
	`longitude` VARCHAR(45),
	`SoftDeleteFlag` BOOLEAN,
	PRIMARY KEY(`location_id`)
);
CREATE TABLE `event_images`(
	`CreatedBy` VARCHAR(32),
	`CreatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`event_id` BIGINT NOT NULL,
	`event_image_id` BIGINT NOT NULL AUTO_INCREMENT,
	`image_url` VARCHAR(256),
	`img_name` VARCHAR(200),
	`LastUpdatedBy` VARCHAR(32),
	`LastUpdatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`SoftDeleteFlag` BOOLEAN,
	PRIMARY KEY(`event_image_id`)
);
CREATE TABLE `event_metrics`(
	`CreatedBy` VARCHAR(32),
	`CreatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`event_id` BIGINT NOT NULL,
	`isshared` VARCHAR(45),
	`isviewed` VARCHAR(45),
	`LastUpdatedBy` VARCHAR(32),
	`LastUpdatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`metric_id` BIGINT NOT NULL AUTO_INCREMENT,
	`SoftDeleteFlag` BOOLEAN,
	`user_id` BIGINT NOT NULL,
	PRIMARY KEY(`metric_id`)
);
CREATE TABLE `event_banners`(
	`banner_url` VARCHAR(256),
	`CreatedBy` VARCHAR(32),
	`CreatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`event_banner_id` BIGINT NOT NULL AUTO_INCREMENT,
	`event_id` BIGINT NOT NULL,
	`img_name` VARCHAR(200),
	`LastUpdatedBy` VARCHAR(32),
	`LastUpdatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`SoftDeleteFlag` BOOLEAN,
	PRIMARY KEY(`event_banner_id`)
);
CREATE TABLE `login_mode`(
	`CreatedBy` VARCHAR(32),
	`CreatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`LastUpdatedBy` VARCHAR(32),
	`LastUpdatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`login_mode_id` BIGINT NOT NULL AUTO_INCREMENT,
	`loginmode` VARCHAR(128),
	`SoftDeleteFlag` BOOLEAN,
	PRIMARY KEY(`login_mode_id`)
);
CREATE TABLE `event_category`(
	`category_name` VARCHAR(256),
	`CreatedBy` VARCHAR(32),
	`CreatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`evet_cat_id` BIGINT NOT NULL,
	`LastUpdatedBy` VARCHAR(32),
	`LastUpdatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`SoftDeleteFlag` BOOLEAN,
	PRIMARY KEY(`evet_cat_id`)
);
ALTER TABLE `presenter`
	ADD CONSTRAINT `24f7456677e45be1bf806f755ce2bb` FOREIGN KEY(`session_id`) REFERENCES `event_sessions`(`event_session_id`) ON DELETE CASCADE;

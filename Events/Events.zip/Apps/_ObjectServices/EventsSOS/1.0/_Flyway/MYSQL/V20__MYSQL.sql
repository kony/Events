ALTER TABLE `event_sessions`
	ADD CONSTRAINT `8ce0ab51ccc6c23915306be3cc09bb` FOREIGN KEY(`event_id`) REFERENCES `event`(`event_id`);

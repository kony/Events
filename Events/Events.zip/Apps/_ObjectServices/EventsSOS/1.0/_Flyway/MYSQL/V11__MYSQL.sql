ALTER TABLE `event_metrics`
	ADD `action` BIGINT,
	DROP COLUMN `isshared`,
	DROP COLUMN `isviewed`;

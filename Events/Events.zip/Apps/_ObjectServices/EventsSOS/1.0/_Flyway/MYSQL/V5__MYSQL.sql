DROP TABLE `login_details`;
